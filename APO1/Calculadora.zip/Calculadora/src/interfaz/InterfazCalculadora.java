package interfaz;

import java.awt.GridLayout;

/**
 * Celso Javier Rodriguez Pizza
 */

import javax.swing.JFrame;

public class InterfazCalculadora extends JFrame
{
	// ATRIBUTOS
	private PanelDatos panelDatos;
	private PanelOperaciones panelOperaciones;
	private PanelResultados panelResultados;

	public InterfazCalculadora() 
	{
		// DISEÑO
		setTitle("Calculadora Celso");
		setSize(250, 300);
		setVisible(true);
		setResizable(false);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		setLayout(new GridLayout(3, 1));
		
		// CREAR LOS OBJETOS
		panelDatos = new PanelDatos();
		add(panelDatos);
		
		panelOperaciones = new PanelOperaciones();
		add(panelOperaciones);
		
		panelResultados = new PanelResultados();
		add(panelResultados);
	}

	public static void main(String[] args) 
	{
		InterfazCalculadora miHP = new InterfazCalculadora();
		miHP.setVisible(true);

	}

}
