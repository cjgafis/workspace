package interfaz;

import java.awt.Color;
import java.awt.GridLayout;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.TitledBorder;

public class PanelResultados extends JPanel
{
	// ATRIBUTOS
	private JLabel labResultado;
	private JTextField txtResultado;
	private JLabel labVacio1;
	private JButton butLimpiar;

	public PanelResultados() 
	{
		// DISEÑO
		TitledBorder borde = BorderFactory.createTitledBorder("Resultados");
		setBorder(borde);
		borde.setTitleColor(Color.BLUE);
		setLayout(new GridLayout(2, 2));
		
		// CREAR LOS OBJETOS
		labResultado = new JLabel("Resultado");
		txtResultado = new JTextField("");
		txtResultado.setEditable(false);
		labVacio1 = new JLabel("");
		butLimpiar = new JButton("Limpiar");
		
		// AGREGAR LOS OBJETOS AL PANEL
		add(labResultado);
		add(txtResultado);
		add(labVacio1);
		add(butLimpiar);
	}

}
