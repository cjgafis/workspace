package interfaz;

import java.awt.Color;
import java.awt.GridLayout;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JPanel;
import javax.swing.border.TitledBorder;

public class PanelOperaciones extends JPanel
{
	// ATRIBUTOS
	private JButton butSumar;
	private JButton butRestar;
	private JButton butMultiplicar;
	private JButton butDividir;
	

	public PanelOperaciones() 
	{
		// DISEÑO
		TitledBorder borde = BorderFactory.createTitledBorder("Operaciones");
		setBorder(borde);
		borde.setTitleColor(Color.BLUE);
		setLayout(new GridLayout(2, 2));
		
		// CREAR LOS OBJETOS
		butSumar = new JButton("Sumar");
		butRestar = new JButton("Restar");
		butMultiplicar = new JButton("Multiplicar");
		butDividir = new JButton("Dividir");
		
		// AGREGAR LOS OBJETOS AL PANEL
		add(butSumar);
		add(butRestar);
		add(butMultiplicar);
		add(butDividir);
	}

}
