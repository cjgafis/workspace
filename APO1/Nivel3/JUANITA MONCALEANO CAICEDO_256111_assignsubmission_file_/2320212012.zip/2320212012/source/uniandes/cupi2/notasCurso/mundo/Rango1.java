package uniandes.cupi2.notasCurso.mundo;

public class Rango1 {
	
		private double r1;
		private double r2;
		private double r3;
		
	    private double metodo1;
	    private double metodo2;
}
