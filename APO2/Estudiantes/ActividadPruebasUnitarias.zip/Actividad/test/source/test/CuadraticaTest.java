package test;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

import mundo.Cuadratica;

public class CuadraticaTest 
{

	private Cuadratica cuadratica;

	private void setup1() 
	{
		cuadratica = new Cuadratica (2,7,4);

	}

	@Test
	private void calcularRaiz1Test() 
	{
		setup1();
		double valorReal = -2.78;
		double valorMetodo = cuadratica.calcularRaiz1();
		assertEquals(valorReal, valorMetodo, 0.1);
	}

	private void setup2() 
	{
		cuadratica = new Cuadratica (0,7,4);
	}

	@Test
	private void calculadoraRaiz2Test() 
	{
		setup2() ;
		double valorReal = -0.57;
		double valorMetodo = cuadratica.calcularRaiz2();
		assertEquals(valorReal, valorMetodo, 0.1);	
	}




}
