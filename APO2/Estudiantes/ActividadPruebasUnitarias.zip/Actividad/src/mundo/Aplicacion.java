package mundo;

import java.util.Scanner;

public class Aplicacion 
{
 

	public static void main(String[] args)
	{
		// TODO Auto-generated method stub

		Scanner sc = new Scanner(System.in);
	
		System.out.println("Por favor ingrese el primer numero a: ");
		double a = Double.parseDouble(sc.nextLine());
		
		System.out.println("Por favor ingrese el segundo numero b: ");
		double b = Double.parseDouble(sc.nextLine());
		
		System.out.println("Por favor ingrese el tercero numero c: ");
		double c = Double.parseDouble(sc.nextLine());
		Cuadratica oc = new Cuadratica(a,b,c);
		System.out.println("La raiz 1 es igual a: "  + oc.calcularRaiz1());
		System.out.println("La raiz 2 es igual a: "  + oc.calcularRaiz2());
		sc.close();
		
	}

}
