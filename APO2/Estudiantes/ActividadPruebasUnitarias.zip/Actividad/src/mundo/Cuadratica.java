package mundo;

public class Cuadratica
{
	private double a;
	private double b;
	private double c;

	public Cuadratica(double a, double b, double c) throws IllegalArgumentException
	{
		if (a == 0) 
		{
			verificarInvariante();
			throw new IllegalArgumentException("a no puede ser zero");
		}

		this.a = a;
		this.b = b;
		this.c = c;
	}

	public double calcularRaiz1() throws IllegalArgumentException
	{
		double discriminante = b * b - 4 * a * c;
		if (discriminante < 0) 
		{
			throw new IllegalArgumentException("La ecuación no tiene raices reales");
		}
		double raiz1 = (-b + Math.sqrt(discriminante)) / (2 * a);
		return raiz1;
	}

	public double calcularRaiz2() throws IllegalArgumentException
	{
		double discriminante = b * b - 4 * a * c;
		if (discriminante < 0) 
		{
			throw new IllegalArgumentException("La ecuación no tiene raices reales");
		}
		double raiz2 = (-b - Math.sqrt(discriminante)) / (2 * a);
		return raiz2;
	}

	public double getA() {
		return a;
	}

	public void setA(double a) {
		this.a = a;
	}

	public double getB() {
		return b;
	}

	public void setB(double b) {
		this.b = b;
	}

	public double getC() {
		return c;
	}

	public void setC(double c) {
		this.c = c;
	}
	
	private void verificarInvariante() 
	{
		
		assert (a != 0);
		
	}

}
