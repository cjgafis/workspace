/**~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
 * $Id$
 * Universidad de los Andes (Bogot� - Colombia)
 * Departamento de Ingenier�a de Sistemas y Computaci�n
 * Licenciado bajo el esquema Academic Free License version 2.1
 *
 * Proyecto Cupi2
 * Ejercicio: Club
 * Autor: Jorge Jim�nez- Julio 2005
 * Autor inicial: Mario S�nchez
 * ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
 */
package uniandes.cupi2.club.mundo;

/**
 * Clase que modela una factura en el club
 */
public class Factura
{
    // -----------------------------------------------------------------
    // Atributos
    // -----------------------------------------------------------------
    /**
     * Es la descripci�n del consumo que gener� esta factura
     */
    private String concepto;

    /**
     * Es el valor del consumo que gener� la factura
     */
    private double valor;

    /**
     * Nombre de aqu�l que hizo el consumo que gener� la factura
     */
    private String nombre;

    // -----------------------------------------------------------------
    // Constructores
    // -----------------------------------------------------------------

    /**
     * Construye un objeto factura asociado a un consumo de un socio o de un autorizado.
     * @param elNombre corresponde al nombre del que hizo el consumo. Este nombre es v�lido en el Club. - elNombre!=null
     * @param elConcepto corresponde a el concepto del consumo - elConcepto!=null
     * @param elValor corresponde al valor del consumo
     */
    public Factura( String elNombre, String elConcepto, double elValor )
    {

        nombre = elNombre;
        concepto = elConcepto;
        valor = elValor;
    }

    // -----------------------------------------------------------------
    // M�todos
    // -----------------------------------------------------------------
    /**
     * Este m�todo sirve para conocer el concepto de la factura. <br>
     * <b>post: </b> Retorn� el concepto de la factura <br>
     * @return concepto - concepto de la factura - concepto!=null
     */
    public String darConcepto( )
    {
        return concepto;
    }

    /**
     * Este m�todo sirve para saber el valor de la factura. <br>
     * <b>post: </b> Retorn� el valor de la factura <br>
     * @return valor - valor de la factura - valor!=null
     */
    public double darValor( )
    {
        return valor;
    }

    /**
     * Este m�todo sirve para saber el nombre de quien hizo el consumo que gener� la factura. <br>
     * <b>post: </b> Retorn� el nombre que aparece en la factura <br>
     * @return nombre - nombre en la factura - nombre!=null
     */
    public String darNombre( )
    {
        return nombre;
    }

    /**
     * Este m�todo se usa para obtener una cadena que representa a la factura
     * @return factura - una cadena de caracteres con la informaci�n de la factura. Tiene concatenado: el concepto de la factura, el valor y el nombre del socio o del
     *         autorizado quien hizo el consumo - factura !=null
     */
    public String toString( )
    {
        String factura = concepto + "    $" + valor + "    (" + nombre + ")";
        return factura;
    }
}