/**~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
 * $Id$
 * Universidad de los Andes (Bogot� - Colombia)
 * Departamento de Ingenier�a de Sistemas y Computaci�n
 * Licenciado bajo el esquema Academic Free License version 2.1
 *
 * Proyecto Cupi2
 * Ejercicio: Club
 * Autor: Jorge Jim�nez- Julio 2005
 * Autor inicial: Mario S�nchez
 * Autor: Pablo Barvo - 26-Ago-2005
 * ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
 */
package uniandes.cupi2.club.mundo;

import java.util.ArrayList;

/**
 * Clase que modela un club
 */
public class Club
{
    // -----------------------------------------------------------------
    // Atributos
    // -----------------------------------------------------------------
    /**
     * Es la colecci�n de socios del Club
     */
    private ArrayList socios;

    // -----------------------------------------------------------------
    // Constructor
    // -----------------------------------------------------------------

    /**
     * Constructor de un nuevo club vac�o <br>
     * <b>post: </b> Se crea un club vac�o y se inicializa la colecci�n de socios.
     */
    public Club( )
    {
        socios = new ArrayList( );
    }

    // -----------------------------------------------------------------
    // M�todos
    // -----------------------------------------------------------------

    /**
     * Este m�todo afilia un nuevo socio al club. <br>
     * <b>pre: </b> La lista de socios est� inicializada (no es null). <br>
     * <b>post: </b> Se ha afiliado un nuevo socio en el club con los datos dados. <br>
     * @param cedula Es la c�dula del nuevo socio. cedula != null, cedula != ��
     * @param nombre Es el nombre del nuevo socio. nombre != null, nombre != ��
     * @throws Exception si un socio con la misma c�dula ya estaba afiliado al club, dispara una excepci�n indicando que la nueva afiliaci�n no se pudo llevar a cabo .
     */
    public void afiliarSocio( String cedula, String nombre ) throws Exception
    {

        // Revisar que no haya ya un socio con la misma c�dula
        Socio s = buscarSocio( cedula );
        if( s == null )
        {
            // Se crea el objeto del nuevo socio (todav�a no se ha agregado al
            // club)
            Socio nuevoSocio = new Socio( cedula, nombre );
            // se agrega el nuevo socio al club
            socios.add( nuevoSocio );
        }
        else
        {
            throw new Exception( "El socio ya existe" );
        }
    }

    /**
     * Este m�todo sirve para buscar un socio. <br>
     * <b>post: </b> Retorno un socio dada la c�dula, si este no existe se retorno null <br>
     * @param cedula Es la c�dula del socio que se est� buscando - cedula!=null
     * @return elSocio - Retorna el socio buscado. Si la c�dula no pertenece a ning�n socio entonces retorna null
     */
    public Socio buscarSocio( String cedula )
    {
        Socio elSocio = null;

        boolean encontre = false;
        int numSocios = socios.size( );
        for( int i = 0; i < numSocios && !encontre; i++ )
        {
            Socio s = ( Socio )socios.get( i );
            if( s.darCedula( ).equals( cedula ) )
            {
                elSocio = s;
                encontre = true;
            }
        }

        return elSocio;
    }
    
    /**
     * Este m�todo devuelve la lista de autorizados de un socio dada su c�dula.
     * @param cedula La c�dula del socio - cedula != null
     * @return La lista de autorizados del socio
     * @throws Exception - dispara una excepci�n en caso de que el socio no exista.
     */
    public ArrayList darAutorizadosSocio(String cedula) throws Exception{
    	Socio s = buscarSocio(cedula);
    	ArrayList autorizados = new ArrayList();
    	if(s == null){
    		throw new Exception("El socio con esa c�dula no existe."); 
    	}else{
    		autorizados.add(s.darNombre());
    		autorizados.addAll(s.darAutorizados());
    	}
    	return autorizados;
    }

    /**
     * Este m�todo sirve para agregar una nueva persona autorizada a un socio de una c�dula dada. <br>
     * <b>post: </b> Se agreg� un nuevo autorizado, con nombre distinto a todos los ya vinculados, y al del mismo socio <br>
     * @param cedula La c�dula del socio. cedula != null.
     * @param nombreAutorizado El nombre de la persona a autorizar. nombreAutorizado != null.
     * @throws Exception - dispara una excepci�n en caso de que el socio no exista.
     * @throws Exception - dispara una excepci�n si el nombre del socio es igual al de nombre.
     * @throws Exception - dispara una excepci�n si el autorizado ya exist�a en la lista de autorizados de este socio.
     */
    public void agregarAutorizadoSocio(String cedula, String nombreAutorizado) throws Exception{
    	Socio s = buscarSocio(cedula);
    	if(s == null){
    		throw new Exception("El socio con esa c�dula no existe."); 
    	}else{
    		s.agregarAutorizado( nombreAutorizado );
    	}
    }

    /**
     * M�todo que registra un consumo a un autorizado de un socio.<br />
     * <b>post: </b> Se agreg� una nueva factura al vector del socio, Se verifico que es el socio o un autorizado por �l. <br>
     * @param cedula La c�dula del socio. cedula != null
     * @param nombreCliente El nombre del autorizado que realiz� en consumo. nombreCliente != null
     * @param concepto El concepto del consumo. concepto != null.
     * @param valor El valor del consumo. valor >= 0.
     * @throws Exception - dispara una excepci�n en caso de que el socio no exista.
     */
    public void registrarConsumo(String cedula, String nombreCliente, String concepto, double valor) throws Exception{
    	Socio s = buscarSocio(cedula);
    	if(s == null){
    		throw new Exception("El socio con esa c�dula no existe."); 
    	}else{
    		s.registrarConsumo(nombreCliente, concepto, valor);
    	}
    }
    
    /**
     * M�todo que devuelve la lista de facturas de un socio
     * @param cedula La c�dula del socio. cedula != null.
     * @return La lista de facturas del socio.
     * @throws Exception - dispara una excepci�n en caso de que el socio no exista.
     */
    public ArrayList darFacturasSocio(String cedula) throws Exception{
    	ArrayList facturas = new ArrayList();
    	Socio s = buscarSocio(cedula);
    	if(s == null){
    		throw new Exception("El socio con esa c�dula no existe."); 
    	}else{
    		facturas.addAll(s.darFacturas());
    	}
    	return facturas;
    }
    
    
    /**
     * M�todo encargado del pago de la factura de un socio.
     * <b>post: </b> Se borr� la factura del vector del socio <br>
     * @param cedula La c�dula del socio - cedula != null
     * @param facturaIndice El �ndice de la factura a pagar. facturaIndice >= 0
     * @throws Exception - dispara una excepci�n en caso de que el socio no exista.
     */
    public void pagarFacturaSocio(String cedula, int facturaIndice) throws Exception{
    	Socio s = buscarSocio(cedula);
    	if(s == null){
    		throw new Exception("El socio con esa c�dula no existe."); 
    	}else{
    		s.pagarFactura(facturaIndice);
    	}
    }

    // -----------------------------------------------------------------
    // M�todos de Extensi�n
    // -----------------------------------------------------------------

    /**
     * Extensi�n 1
     * @return Resultado extensi�n 1
     */
    public String metodo1( )
    {
        return "respuesta1";
    }

    /**
     * Extensi�n 2
     * @return Resultado extensi�n 2
     */
    public String metodo2( )
    {
        return "respuesta1";
    }
}